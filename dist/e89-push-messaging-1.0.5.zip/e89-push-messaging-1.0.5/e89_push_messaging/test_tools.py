# -*- coding: utf-8 -*-
from django.db.models.signals import pre_delete,post_save
from django.conf import settings

import contextlib

@contextlib.contextmanager
def mock_push(Model):
    """
    Temporarily attaches a receiver to the provided ``signal`` within the scope
    of the context manager.
    The mocked receiver is returned as the ``as`` target of the ``with``
    statement.
    To have the mocked receiver wrap a callable, pass the callable as the
    ``wraps`` keyword argument. All other keyword arguments provided are passed
    through to the signal's ``connect`` method.
    >>> with mock_signal_receiver(post_save, sender=Model) as receiver:
    >>>     Model.objects.create()
    >>>     assert receiver.call_count = 1
    """
    from signals import notify_owner
    send_on_save = settings.PUSH_MODELS[Model._meta.app_label + "." + Model._meta.object_name].get("send_on_save", True)

    fake_receiver = FakeNotifyOwner()

    pre_delete.disconnect(notify_owner, Model)
    pre_delete.connect(fake_receiver, sender=Model)

    if send_on_save:
        post_save.disconnect(notify_owner, Model)
        post_save.connect(fake_receiver, sender=Model)

    old_method = Model.notify_owners
    mock_method = lambda self: fake_receiver(self._meta.model, self, None)
    Model.notify_owners = mock_method
    yield fake_receiver
    pre_delete.disconnect(fake_receiver, Model)
    pre_delete.connect(notify_owner, sender=Model)

    if send_on_save:
        post_save.disconnect(fake_receiver, Model)
        post_save.connect(notify_owner, sender=Model)
    Model.notify_owners = old_method

class FakeNotifyOwner(object):
    def __init__(self):
        self.notified = set()

    def __call__(self, sender, instance, signal, **kwargs):
        from signals import notify_owner

        result = notify_owner(sender, instance, signal, testing=True)

        if result is None:
            # Push was not sent
            return
        owners, exclude_reg_ids, include_reg_ids = result

        for owner in owners:
            if type(owner) == type(1):
                owner_id = owner
            else:
                owner_id = owner.id
            if not owner_id in exclude_reg_ids:
                self.notified.add(owner_id)

        for include in include_reg_ids:
            if type(include) == type(1):
                self.notified.add(include)
