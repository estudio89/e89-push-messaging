__VERSION__ = "1.0.9"
default_app_config = 'e89_push_messaging.apps.E89PushMessagingConfig'